import re
import sys
import os

def process_chapters(input_file, output_file=None):
    """
    处理小说文件中的重复章节标题
    
    参数:
    input_file -- 输入文件路径
    output_file -- 输出文件路径（可选，默认为输入文件路径加"_processed"后缀）
    """
    # 设置默认输出文件名
    if output_file is None:
        base_name, ext = os.path.splitext(input_file)
        output_file = f"{base_name}_processed{ext}"
    
    chapter_counter = {}
    new_lines = []
    
    try:
        with open(input_file, 'r', encoding='utf-8') as f:
            lines = f.readlines()
    except FileNotFoundError:
        print(f"错误：文件 '{input_file}' 不存在")
        sys.exit(1)
    iCount = 0
    for line in lines:
        if(r'========================================' in line.strip()):
            continue
        # 检测章节标题行：以##开头，包含"第"和"章"
        if re.match(r'^##\s*第[零一二三四五六七八九十百千0-9]+\s*章', line.strip()):
            # 提取标准化的章节标题（去除多余空格）
            iCount += 1
            new_lines.append(f'\n第{iCount}章\n')
        else:
            s = line.strip().replace(f' ','')
            s = s.strip().replace(f'“','')
            s = s.strip().replace(f'”','')
            s = f'　　{s}\n'
            new_lines.append(s)
    
    # 写入处理后的内容
    with open(output_file, 'w', encoding='utf-8') as f:
        f.writelines(new_lines)
    
    print(f"\n处理完成!")
    print(f"输入文件: {input_file}")
    print(f"输出文件: {output_file}")
    print(f"共修改了 {sum(c > 1 for c in chapter_counter.values())} 个重复章节标题")

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("小说章节标题处理工具")
        print("用法: python script.py <输入文件> [输出文件]")
        print("示例:")
        print("  python script.py novel.txt")
        print("  python script.py input.txt output_processed.txt")
        sys.exit(1)
    
    input_file = sys.argv[1]
    output_file = sys.argv[2] if len(sys.argv) > 2 else None
    
    process_chapters(input_file, output_file)