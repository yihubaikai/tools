import time
import os
import argparse  # 导入argparse模块
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException

# --- 配置区 (常量) ---
# 这些定位器通常在同一个网站上是固定的，所以保留为常量
TITLE_SELECTOR = 'div.header h1'
CONTENT_SELECTOR = 'div.content'
NEXT_BUTTON_XPATH = "//a[contains(text(), '下一页') or contains(text(), '下一章')]"

# --- 辅助函数 ---
def sanitize_filename(name):
    """清理文件名，移除不合法字符，使其在各操作系统中都可用"""
    # 移除Windows和Linux中常见的文件名非法字符
    return "".join(c for c in name if c not in '<>:"/\\|?*').strip()

# --- 脚本主逻辑 ---
def scrape_with_selenium(novel_name, start_url):
    """
    健壮的Selenium采集函数，从命令行接收小说名和起始URL。
    
    Args:
        novel_name (str): 用于生成输出文件名的小说名字。
        start_url (str): 采集的起始网址。
    """
    
    # 根据传入参数生成输出文件名
    output_filename = f"{sanitize_filename(novel_name)}.txt"
    print(f"任务开始: 采集《{novel_name}》")
    print(f"内容将保存至: {output_filename}")
    print(f"起始网址: {start_url}")
    
    # --- 浏览器设置 ---
    options = webdriver.ChromeOptions()
    options.add_argument('--ignore-certificate-errors')
    # options.add_argument('--headless')
    options.add_argument('--log-level=3')
    options.add_experimental_option('excludeSwitches', ['enable-logging'])

    service = Service(ChromeDriverManager().install())
    driver = webdriver.Chrome(service=service, options=options)
    
    wait = WebDriverWait(driver, 10)

    try:
        driver.get(start_url)
        
        with open(output_filename, 'a', encoding='utf-8') as f:
            while True:
                current_page_url = driver.current_url
                print(f"--- 开始处理页面: {current_page_url} ---")
                
                # ... (内部逻辑与之前版本完全相同)
                chapter_title, content_text = "", ""
                page_valid = True

                try:
                    title_element = wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, TITLE_SELECTOR)))
                    chapter_title = title_element.text
                except TimeoutException:
                    print(f"错误: 找不到 [章节标题]。Selector: '{TITLE_SELECTOR}'")
                    chapter_title = f"标题获取失败 - {current_page_url}"
                    page_valid = False

                try:
                    content_element = wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, CONTENT_SELECTOR)))
                    content_text = content_element.text
                except TimeoutException:
                    print(f"错误: 找不到 [正文内容]。Selector: '{CONTENT_SELECTOR}'")
                    content_text = "正文内容获取失败。"
                    page_valid = False

                if chapter_title or content_text:
                    f.write(f"## {chapter_title}\n\n")
                    f.write(f"{content_text}\n\n")
                    f.write("="*40 + "\n\n")
                    f.flush()
                    os.fsync(f.fileno())
                    
                    if page_valid:
                        print(f"成功采集章节: {chapter_title} (数据已保存)")
                    else:
                        print("警告: 页面数据不完整，但已将获取到的部分强制保存。")
                
                try:
                    print("正在查找 '下一页' 或 '下一章' 按钮...")
                    next_button = wait.until(EC.element_to_be_clickable((By.XPATH, NEXT_BUTTON_XPATH)))
                    button_text = next_button.text.strip()
                    print(f"找到并点击按钮: [{button_text}]")
                    next_button.click()
                    time.sleep(1.5)
                except TimeoutException:
                    print("关键错误: 找不到可点击的 [下一页] 或 [下一章] 按钮。采集流程结束。")
                    break
    
    finally:
        driver.quit()
        print("\n浏览器已关闭。")

#https://156.251.24.177/info/47341/608227.html
# ★★★ 脚本启动入口 ★★★
if __name__ == "__main__":
    # 1. 创建参数解析器
    parser = argparse.ArgumentParser(
        description="一个通用的文章采集脚本，支持从命令行指定小说名和起始网址。",
        formatter_class=argparse.RawTextHelpFormatter  # 保持帮助文本格式
    )
    
    # 2. 添加参数定义
    parser.add_argument(
        "novel_name", 
        type=str, 
        help="要采集的小说名字。\n它将被用作输出文件的名称 (例如: \"神秘复苏\")。"
    )
    parser.add_argument(
        "start_url", 
        type=str, 
        help="采集的起始章节网址。\n请确保将网址用双引号括起来。"
    )
    
    # 3. 解析命令行传入的参数
    args = parser.parse_args()
    
    # 4. 调用主函数，并传入解析到的参数
    scrape_with_selenium(args.novel_name, args.start_url)

    print(f"\n采集任务《{args.novel_name}》已完成。")