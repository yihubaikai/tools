import time
import os  # 导入os模块，用于文件系统操作
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException

# --- 配置区 ---

# 1. 起始URL
start_url = "https://156.251.24.177/info/47341/608227.html"  # <--- 你的URL

# 2. 输出文件名
output_filename = "姜妍芳茴.txt"

# 3. 定位器 (CSS Selector)
TITLE_SELECTOR = 'div.header h1'
CONTENT_SELECTOR = 'div.content'

# 4. 下一页/下一章按钮的定位器 (XPath)
NEXT_BUTTON_XPATH = "//a[contains(text(), '下一页') or contains(text(), '下一章')]"

# --- 脚本主逻辑 ---

def scrape_with_selenium_realtime_save():
    """健壮的Selenium采集函数，实现实时保存"""
    
    # --- 浏览器设置 ---
    options = webdriver.ChromeOptions()
    options.add_argument('--ignore-certificate-errors')
    # options.add_argument('--headless') 
    options.add_argument('--log-level=3')
    options.add_experimental_option('excludeSwitches', ['enable-logging'])

    service = Service(ChromeDriverManager().install())
    driver = webdriver.Chrome(service=service, options=options)
    
    wait = WebDriverWait(driver, 10)

    try:
        driver.get(start_url)
        
        # ★★★ 关键修改 1: 使用 'a' (append) 模式打开文件 ★★★
        # 这意味着每次运行脚本都会在文件末尾追加，而不是覆盖。
        # 如果想每次都重新开始，请在运行前手动删除该文件。
        with open(output_filename, 'a', encoding='utf-8') as f:
            while True:
                current_page_url = driver.current_url
                print(f"--- 开始处理页面: {current_page_url} ---")
                
                chapter_title, content_text = "", ""
                page_valid = True

                # --- 获取章节标题 ---
                try:
                    title_element = wait.until(
                        EC.presence_of_element_located((By.CSS_SELECTOR, TITLE_SELECTOR))
                    )
                    chapter_title = title_element.text
                except TimeoutException:
                    print(f"错误: 找不到 [章节标题]。Selector: '{TITLE_SELECTOR}'")
                    chapter_title = f"标题获取失败 - {current_page_url}"
                    page_valid = False

                # --- 获取正文内容 ---
                try:
                    content_element = wait.until(
                        EC.presence_of_element_located((By.CSS_SELECTOR, CONTENT_SELECTOR))
                    )
                    content_text = content_element.text
                except TimeoutException:
                    print(f"错误: 找不到 [正文内容]。Selector: '{CONTENT_SELECTOR}'")
                    content_text = "正文内容获取失败。"
                    page_valid = False

                # --- 写入并实时保存 ---
                if chapter_title or content_text:
                    f.write(f"## {chapter_title}\n\n")
                    f.write(f"{content_text}\n\n")
                    f.write("="*40 + "\n\n")
                    
                    # ★★★ 关键修改 2: 强制刷新到磁盘 ★★★
                    f.flush()  # 1. 清空Python内部文件缓冲区，将数据写入操作系统。
                    os.fsync(f.fileno()) # 2. 强制操作系统将数据从缓存写入物理磁盘。
                    
                    if page_valid:
                        print(f"成功采集章节: {chapter_title} (数据已保存至磁盘)")
                    else:
                        print("警告: 页面数据不完整，但已将获取到的部分强制保存。")
                
                # --- 查找并点击下一页/下一章 ---
                try:
                    print("正在查找 '下一页' 或 '下一章' 按钮...")
                    next_button = wait.until(
                        EC.element_to_be_clickable((By.XPATH, NEXT_BUTTON_XPATH))
                    )
                    button_text = next_button.text.strip()
                    print(f"找到并点击按钮: [{button_text}]")
                    next_button.click()
                    time.sleep(1.5)
                except TimeoutException:
                    print("关键错误: 找不到可点击的 [下一页] 或 [下一章] 按钮。采集流程结束。")
                    break
    
    finally:
        driver.quit()
        print("\n浏览器已关闭。")

if __name__ == "__main__":
    scrape_with_selenium_realtime_save()
    print(f"所有内容已追加保存到文件: {output_filename}")